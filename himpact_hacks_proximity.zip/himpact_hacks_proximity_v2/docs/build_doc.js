const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  ImageRun, PageBreak, LevelFormat, convertInchesToTwip
} = require("docx");
const fs = require("fs");
const path = require("path");

const ASSETS = path.join(__dirname, "../website/assets");
const TEAL = "1F8A82";
const INK = "1A1A1A";
const DIM = "5B6470";
const LINE = "D8DEE4";

const img = (file, width) => fs.readFileSync(path.join(ASSETS, file));

function H1(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_1, spacing: { before: 400, after: 200 } });
}
function H2(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_2, spacing: { before: 300, after: 150 } });
}
function P(text, opts = {}) {
  return new Paragraph({
    children: [new TextRun({ text, ...opts })],
    spacing: { after: 160 },
  });
}
function Lede(text) {
  return new Paragraph({
    children: [new TextRun({ text, italics: true, color: DIM, size: 22 })],
    spacing: { after: 240 },
  });
}
function Bullet(text, bold) {
  return new Paragraph({
    children: [new TextRun({ text, bold: !!bold })],
    bullet: { level: 0 },
    spacing: { after: 90 },
  });
}
function Caption(text) {
  return new Paragraph({
    children: [new TextRun({ text, italics: true, size: 18, color: DIM })],
    spacing: { after: 260 },
    alignment: AlignmentType.CENTER,
  });
}
function Img(file, widthPx, heightPx, maxW = 560) {
  const scale = Math.min(1, maxW / widthPx);
  return new Paragraph({
    children: [new ImageRun({ type: "png", data: img(file), transformation: { width: widthPx * scale, height: heightPx * scale } })],
    alignment: AlignmentType.CENTER,
    spacing: { before: 120, after: 60 },
  });
}
function cell(text, opts = {}) {
  return new TableCell({
    width: { size: opts.width || 2500, type: WidthType.DXA },
    shading: opts.header ? { type: ShadingType.CLEAR, fill: "EDF3F2" } : undefined,
    children: [new Paragraph({
      children: [new TextRun({ text, bold: !!opts.header, size: opts.size || 20, color: opts.header ? TEAL : INK })],
    })],
  });
}
function simpleTable(headers, rows, widths) {
  return new Table({
    width: { size: 9350, type: WidthType.DXA },
    columnWidths: widths,
    rows: [
      new TableRow({ children: headers.map((h, i) => cell(h, { header: true, width: widths[i] })) }),
      ...rows.map(r => new TableRow({ children: r.map((c, i) => cell(c, { width: widths[i] })) })),
    ],
  });
}

const doc = new Document({
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1080, bottom: 1080, left: 1260, right: 1260 } } },
    children: [
      // TITLE
      new Paragraph({ children: [new TextRun({ text: "HIMPact Hacks '26", bold: true, color: TEAL, size: 22 })], spacing: { after: 80 } }),
      new Paragraph({
        children: [new TextRun({ text: "PROXIMITY: QUANTIFYING CD8+ T-CELL SPATIAL EXCLUSION", bold: true, size: 40 })],
        spacing: { after: 60 },
      }),
      new Paragraph({
        children: [new TextRun({ text: "AS A CLINICIAN-FACING PREDICTOR OF MELANOMA PROGRESSION", bold: true, size: 40 })],
        spacing: { after: 240 },
      }),
      new Paragraph({ children: [new TextRun({ text: "By Christine Li", size: 22, color: DIM })], spacing: { after: 40 } }),
      new Paragraph({ children: [new TextRun({ text: "Research Club", size: 22, color: DIM })], spacing: { after: 400 } }),

      H1("Abstract"),
      P("Standard melanoma pathology quantifies immune infiltration by counting CD8+ cytotoxic T-cells within a tumor sample. This project argues that where those T-cells sit relative to malignant melanocytes is at least as informative as how many are present: a T-cell held 300 μm away by stromal cancer-associated fibroblasts cannot engage the tumor cell it cannot reach. We present Proximity, a spatial analysis tool that computes the nearest-neighbour (NN) distance between CD8+ T-cells and melanocytes from cell-coordinate data, aggregates it per patient, and returns an auditable, threshold-based recommendation for clinicians. Built and validated end-to-end on a literature-grounded synthetic dataset (n=60) over a hackathon weekend, the pipeline recovers a statistically significant relationship between mean NN distance and simulated tumor thickness (Breslow depth) (Pearson r = 0.53, p < 0.0001), while transparently reporting a non-significant relationship with simulated survival outcome — both results are reported honestly as a proof of concept, not a validated clinical claim, with an explicit roadmap to real-data validation and regulatory review."),

      H1("Introduction"),
      P("Melanoma remains one of the most lethal forms of skin cancer, and response to immunotherapy varies widely between patients in ways that simple immune cell counts do not explain. A growing body of spatial oncology research shows that the melanoma tumor microenvironment (TME) is not a uniform mixture of cells but a spatially organized ecosystem: cancer-associated fibroblasts (CAFs) physically remodel the extracellular matrix to wall off immune cells, tumor-associated macrophages actively suppress cytotoxic T-cell recruitment, and the resulting spatial exclusion of CD8+ T-cells from the tumor margin is itself informative about disease trajectory, independent of total immune cell count."),
      P("This project asks a specific, quantitative version of that idea: how does the average nearest-neighbour distance between CD8+ T-cells and malignant melanocytes correlate with tumor thickness (Breslow depth) and patient survival outcomes? And can that relationship be turned into a tool a clinician, not a computational biologist, could actually use?"),

      H2("Importance, Tractability, Neglectedness"),
      Bullet("Importance: Melanoma drives a disproportionate share of skin-cancer mortality, and immunotherapy response heterogeneity remains poorly explained by standard pathology, directly affecting treatment decisions for real patients.", true),
      Bullet("Tractability: Multiplexed immunofluorescence (mIF) imaging already exists in research and increasingly clinical pipelines. Nearest-neighbour spatial statistics (the point-pattern \"G-function\") are well-established, computationally cheap mathematics — the missing piece is a fast, interpretable translation layer between raw coordinates and a clinical recommendation.", true),
      Bullet("Neglectedness: Existing spatial-omics tools (e.g. Squidpy) are built for computational biologists, not practicing oncologists. Few tools translate spatial statistics into a plain-language, auditable clinical readout.", true),

      H1("Literature Review"),
      P("The melanoma TME is a dynamic ecosystem in which cancer-associated fibroblasts, tumor-associated macrophages, regulatory T-cells, and exhausted CD8+ T-cells interact to drive tumor progression and therapeutic resistance. CAFs, which can constitute up to 80% of tumor mass, remodel the extracellular matrix and create physical barriers that impede immune cell infiltration and drug delivery. This stromal exclusion mechanism is the direct biological basis for this project's central hypothesis: that spatial distance between immune and tumor cells, not just their relative counts, is a functionally meaningful and measurable signal."),
      P("Complementary evidence from multiplexed imaging studies shows that the melanoma TME exhibits substantial intra- and inter-tumoral heterogeneity, and that cellular composition and spatial organization differ markedly even between regions of the same biopsy — reinforcing that spatial context, not aggregate cell counts, carries prognostic information that bulk analysis discards. Full citations are provided in the accompanying literature review document."),

      H1("Our Proposal"),
      H2("Summary"),
      P("Proximity is a Python-based spatial analysis pipeline paired with a clinician-facing web interface. Given cell-coordinate data (CD8+ T-cell and melanocyte positions in a tissue sample), it computes per-cell nearest-neighbour distances, aggregates them into per-patient statistics, visualizes both the raw spatial distribution and the local density of immune infiltration, and returns a rule-based, auditable classification and recommendation."),

      H2("Key Features"),
      Bullet("Nearest-neighbour distance computation via KD-tree spatial indexing (O(n log n))"),
      Bullet("Per-patient aggregate statistics: mean, standard deviation, median NN distance, and percentage of T-cells beyond a functional-engagement threshold"),
      Bullet("Density heatmaps alongside raw distribution scatterplots, distinguishing where cells sit from how concentrated they are"),
      Bullet("Correlation analysis against tumor thickness (Breslow depth) and survival outcome, with both parametric (Pearson) and non-parametric (Spearman) statistics reported"),
      Bullet("A rule-based (not black-box) clinical recommendation layer, so a physician can see exactly why a case was flagged"),

      H2("Data & Methodology"),
      P("Real HTAN and TCGA-SKCM multiplexed IF datasets require registered access, large downloads, and QuPath-based cell segmentation — infrastructure that does not fit inside a hackathon weekend. Rather than skip data entirely or attempt a rushed partial download, Proximity uses a literature-grounded synthetic dataset of 60 virtual patients, generated to reproduce the specific stromal-exclusion mechanism described in the literature review: CD8+ T-cell exclusion distance from the tumor margin scales with simulated Breslow depth, with realistic per-patient heterogeneity and noise added so the resulting correlation is representative rather than trivially perfect. This is disclosed as a design decision throughout this document, not a limitation discovered after the fact."),

      H1("The Prototype"),
      P("The tool classifies each case into one of three spatial immune phenotypes based on mean NN distance, using a 50 μm functional-engagement threshold drawn directly from the literature review's discussion of stromal exclusion distance."),

      H2("Case 1 — Immune-Infiltrated"),
      P("Mean NN distance 26.9 μm, Breslow depth 1.29 mm. T-cells sit close to the tumor margin, consistent with active immune engagement. No additional flag raised."),
      Img("case_infiltrated.png", 653, 730, 340),
      Caption("CD8+ T-cell density (heat) around melanocyte tumor mass (teal) — infiltrated case."),

      H2("Case 2 — Intermediate"),
      P("Mean NN distance 44.7 μm, Breslow depth 1.54 mm. T-cells are moderately distanced; the tool recommends monitoring alongside other biomarkers rather than an immediate flag."),
      Img("case_intermediate.png", 742, 724, 340),
      Caption("Intermediate spatial exclusion — moderate T-cell distance from tumor margin."),

      H2("Case 3 — Immune-Excluded (high-risk combination)"),
      P("Mean NN distance 232.9 μm, Breslow depth 4.23 mm. Mean distance far exceeds the 50 μm engagement threshold, combined with a thick tumor — the tool flags this as a high-risk combination and recommends consideration for immunotherapy-sensitizing strategies or a closer follow-up interval."),
      Img("case_excluded.png", 738, 683, 340),
      Caption("Pronounced spatial exclusion — T-cells confined to the tumor periphery, unable to functionally engage."),

      new Paragraph({ children: [new PageBreak()] }),

      H1("The Math"),
      H2("1. Nearest-neighbour distance"),
      P("For every CD8+ T-cell, the Euclidean distance to the nearest melanocyte is computed: d(Ti) = minj ||Ti − Mj||2. This is the classical point-pattern nearest-neighbour (\"G-function\") statistic (Diggle, 2003), computed here via a KD-tree (SciPy cKDTree) for O(n log n) queries rather than an O(n·m) brute-force comparison."),
      H2("2. Standard deviation of NN distance"),
      P("The per-patient mean captures typical T-cell proximity; the standard deviation captures whether exclusion is spatially uniform or patchy. Two tumors can share a mean NN distance while differing sharply in consistency — a high standard deviation alongside a moderate mean often signals a mixed tumor with both infiltrated and excluded regions, information a single average discards."),
      H2("3. Density vs. distribution"),
      P("Distribution describes where points are located (the raw spatial scatter); density describes how concentrated those points are within a given area (a smoothed 2D histogram). Two tumors can have T-cells spread across an identical footprint yet differ substantially in local clustering — a distinction invisible in a scatterplot and only visible as a density heatmap."),
      Img("distribution_comparison.png", 1490, 770, 560),
      Caption("Raw point distribution: thin-tumor T-cells sit close to the tumor edge; thick-tumor T-cells are pushed outward."),
      Img("density_heatmap.png", 1622, 775, 560),
      Caption("Same two cases as density heatmaps — exclusion appears as a dark ring around the tumor mass in the thick-tumor case."),
      H2("4. Correlation with clinical variables"),
      P("Per-patient mean NN distance is correlated against Breslow depth and simulated survival outcome using Pearson's r, with Spearman's rank correlation ρ reported as a non-parametric robustness check given the right-skewed clinical distribution of Breslow depth."),
      Img("correlation_summary.png", 1630, 655, 560),
      Caption("Left: NN distance rises with Breslow depth. Right: NN distance by simulated 5-year survival outcome."),

      simpleTable(
        ["Relationship", "Statistic", "p-value"],
        [
          ["NN distance vs. Breslow depth", "Pearson r = 0.53", "p = 1.1 × 10⁻⁵"],
          ["NN distance vs. Breslow depth (robustness)", "Spearman ρ = 0.49", "p = 8.2 × 10⁻⁵"],
          ["NN distance vs. simulated survival", "Pearson r = −0.10", "p = 0.44 (not significant)"],
        ],
        [4200, 2800, 2350]
      ),
      P(" ", {}),
      P("The Breslow-depth correlation is strong and significant even with realistic per-patient noise built into the synthetic data. The survival correlation is directionally consistent with the underlying hypothesis but is not statistically significant at n = 60 — this is reported as-is, not adjusted away. Real spatial-immune cohorts typically require 100+ patients with long-term follow-up to adequately power a survival comparison; this result is best read as a demonstration that the pipeline can detect the expected direction of effect, not as a validated prognostic claim."),

      H1("Theory of Change"),
      P("Proximity's path to impact runs through pathology and oncology workflows rather than direct-to-patient deployment. A validated version of this tool would sit alongside existing digital pathology infrastructure, providing oncologists with a spatial biomarker that current cell-count-based reporting does not surface. The mechanism for impact is concrete: cases flagged as immune-excluded with a high-risk Breslow depth combination could be prioritized for immunotherapy-sensitizing strategies or closer surveillance, potentially improving treatment stratification for a subset of patients whose risk is currently underestimated by cell-count-alone reporting. Realizing this requires: (1) retrospective validation on real biopsy cohorts, (2) concordance testing against expert pathologist scoring, and (3) integration into existing pathology software rather than a standalone tool, since adoption follows existing clinical workflows far more readily than new, separate platforms."),

      H1("Cost-Benefit Analysis"),
      H2("Illustrative Financial Projections"),
      simpleTable(
        ["Year", "Focus", "Est. revenue"],
        [
          ["Y1", "Research-use-only licensing to academic pathology labs", "$0 – $15K"],
          ["Y2", "Pilot deployments; grant-funded validation studies", "$15K – $75K"],
          ["Y3", "Post-clearance per-case SaaS licensing to pathology labs", "$150K – $500K"],
        ],
        [1200, 6300, 1850]
      ),
      P(" "),
      P("These are directional planning estimates for a pre-revenue research tool, not a funded projection. The proposed revenue model — per-case or per-seat SaaS licensing to pathology labs — mirrors existing digital pathology analytics products."),

      H2("Implementation & Regulatory Timeline"),
      simpleTable(
        ["Phase", "Milestone", "Est. timeline"],
        [
          ["0", "Retrospective validation on a real HTAN/TCGA-SKCM cohort with known outcomes", "3–6 mo"],
          ["1", "Multi-site concordance study vs. pathologist manual scoring", "6–12 mo"],
          ["2", "SaMD risk classification & pre-submission meeting (FDA) / IVDR classification (EU)", "3–6 mo"],
          ["3", "Clinical validation study sized for regulatory submission", "12–18 mo"],
          ["4", "510(k) / De Novo submission (US) or IVDR technical file (EU)", "6–12 mo review"],
          ["5", "Post-market surveillance & real-world performance monitoring", "ongoing"],
        ],
        [900, 6100, 2350]
      ),
      P(" "),
      P("This is a directional roadmap, not legal or regulatory advice; any real deployment would require guidance from qualified regulatory affairs counsel and an accredited pathology partner.", { italics: true, color: DIM, size: 20 }),

      H1("Evaluation: Risks and Uncertainties"),
      H2("Reliability"),
      P("The tool's classification logic and threshold (50 μm) are drawn from the literature review rather than independently validated against real patient outcomes. Real mIF data also carries segmentation and staining-variability noise not present in the synthetic dataset used here."),
      H2("Privacy and Security"),
      P("Any real deployment would process clinical biopsy data and would need to comply with health data regulations (e.g. HIPAA's 18-identifier Safe Harbor de-identification standard in the US). No real patient data was used in this prototype, so no de-identification step was required for this submission."),
      H2("System Performance and Scalability"),
      P("The KD-tree-based nearest-neighbour computation scales to O(n log n) and completes in under two seconds per case on the synthetic dataset; performance on full-resolution whole-slide mIF images with substantially more cells has not yet been benchmarked."),
      H2("Bias and Clinical Sensitivity"),
      P("A rule-based classifier was deliberately chosen over a black-box model so that clinicians can audit exactly why a case was flagged, reducing the risk of an opaque recommendation influencing treatment decisions without a clear rationale. Thresholds derived from one literature base may not generalize across patient populations or melanoma subtypes without further validation."),

      H1("Limitations"),
      Bullet("Synthetic, not real, patient data — correlation strength on real biopsies will differ from the figures reported here."),
      Bullet("The survival correlation is weak and not statistically significant at this sample size (p = 0.44)."),
      Bullet("The 50 μm engagement threshold is drawn from the literature review, not independently validated against outcomes in this or any real dataset."),
      Bullet("No cell-segmentation step — the pipeline assumes pre-extracted cell coordinates and types, not raw microscopy images."),
      Bullet("Only two cell types are modeled (CD8+ T-cells, melanocytes); real melanoma TME involves CAFs, TAMs, and Tregs, deliberately excluded here for tractability within the project timeline."),

      H1("Conclusion"),
      P("This project demonstrates that a defensible, literature-grounded spatial statistic — nearest-neighbour distance between CD8+ T-cells and melanoma cells — can be computed, visualized, and translated into an auditable clinical recommendation within a single weekend, using synthetic data that reproduces a specific, well-documented biological exclusion mechanism. The tool intentionally favors transparency over polish where the two conflict: reporting a non-significant survival correlation rather than adjusting it away, disclosing every synthetic-data assumption, and using rule-based rather than black-box classification logic. The core contribution is not a finished clinical product but a validated pipeline and a credible, honestly-scoped roadmap from proof-of-concept to real-data validation and regulatory review."),

      H1("Future Steps"),
      Bullet("Retrospective validation on a real HTAN or TCGA-SKCM cohort with known Breslow depth and survival outcomes."),
      Bullet("Extension to a multi-cell-type spatial graph incorporating CAFs, TAMs, and Tregs for a fuller exclusion picture."),
      Bullet("Empirical validation of the 50 μm engagement threshold against real outcome data, rather than adopting it directly from prior literature."),
      Bullet("Integration with QuPath cell-segmentation output so the pipeline can run directly on raw mIF whole-slide images."),
      Bullet("Extension of the same spatial framework to other solid tumors where T-cell exclusion is prognostically relevant (e.g. pancreatic, colorectal cancer)."),

      H1("Appendices"),
      H2("A. Website code"),
      P("Repository: [GitHub link — website/]"),
      H2("B. Tool / analysis code"),
      P("Repository: [GitHub link — data/, analysis/]"),
      H2("C. Data"),
      P("Fully synthetic; generated by data/generate_synthetic_tme.py. No real patient data was used, and therefore no de-identification step (e.g. HIPAA 18-identifier Safe Harbor) was applicable in this prototype."),
      H2("D. AI use disclosure"),
      P("Claude (Anthropic) was used to draft the synthetic data generation methodology and analysis code, build the website front end, and structure this write-up, based on the author's original research question, literature review, and project direction. All modeling assumptions, thresholds, and limitations were reviewed by the author and are disclosed throughout this document."),
      H2("E. Literature review and original project proposal"),
      P("Provided as separate accompanying documents."),
    ],
  }],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync(path.join(__dirname, "Proximity_HIMPact_Hacks_Submission.docx"), buf);
  console.log("Document written.");
});
